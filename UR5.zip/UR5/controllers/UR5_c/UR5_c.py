"""UR5_c controller."""
import enum
# You may need to import some classes of the controller module. Ex:
#  from controller import Robot, Motor, DistanceSensor
from controller import Robot, Motor, DistanceSensor
class states(enum.Enum):
    IDEL = 1
    EEG_1 = 2
    EEG_2 = 3  
    EEG_3 = 4
    EEG_4 = 5
    ERRP = 6
# create the Robot instance.
robot = Robot()
# get the time step of the current world.
timestep = 64
# target_positions = [-1.78, -2.34, -2.38, -1.51]
# grip_open_pos = [0.05,0.05,0.05]
# grip_close_pos = [0.55,0.55,0.55]
# target_positions_pick = [-1, -2.34, -2.38, -1.51]
EEG_pos_1 = [-1.2,0, -0.5]
EEG_pos_2 = [-2.5,0, -0.5]
EEG_pos_3 = [-3.8,0, -0.5]
EEG_pos_4 = [-5.2,0,-0.5]
Idel = [-6.28,-1,-1.5]
speed = 10
ur_motors = []
ur_motors.append(robot.getDevice("shoulder_pan_joint"))
ur_motors.append(robot.getDevice("elbow_joint"))
ur_motors.append(robot.getDevice("shoulder_lift_joint"))
# ur_motors.append(robot.getDevice("wrist_1_joint"))
# ur_motors.append(robot.getDevice("wrist_2_joint"))
for i in range(len(ur_motors)):
    ur_motors[i].setVelocity(speed);
# hand_motors = []
# hand_motors.append(robot.getDevice("finger_1_joint_1"))
# hand_motors.append(robot.getDevice("finger_2_joint_1"))
# hand_motors.append(robot.getDevice("finger_middle_joint_1"))
# hand_sensor = robot.getDevice("finger_middle_joint_1_sensor")
# for i in range(3):
    # hand_motors[i].setVelocity(speed);
# You should insert a getDevice-like function in order to get the
# instance of a device of the robot. Something like:
#  motor = robot.getDevice('motorname')
#  ds = robot.getDevice('dsname')
#  ds.enable(timestep)

# distance_sensor = robot.getDevice("distance sensor")
# distance_sensor.enable(timestep)
# hand_sensor = robot.getDevice("finger_middle_joint_1_sensor")
# hand_sensor.enable(timestep)
current_status = 1

# Main loop:
# - perform simulation steps until Webots is stopping the controller
import socket
from threading import Thread

my_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
ip = '127.0.0.1'
port = 8888
ip_address = (ip, port)
my_socket.bind(ip_address)

def changeState():
    global current_status
    data, _ = my_socket.recvfrom(32)
    current_status = int(data.decode('utf-8'))
    
while robot.step(timestep) != -1:
    # print('Hello')
    t1 = Thread(target = changeState)
    t1.start()
    print(current_status)
    # print('Conj')
    if (current_status==1):
        for i in range(len(ur_motors)):
            ur_motors[i].setPosition(Idel[i])
    if(current_status==2):
        for i in range(len(ur_motors)):
            ur_motors[i].setPosition(EEG_pos_1[i])
    if(current_status==3):
        for i in range(len(ur_motors)):
            ur_motors[i].setPosition(EEG_pos_2[i])
    if(current_status==4):
        for i in range(len(ur_motors)):
            ur_motors[i].setPosition(EEG_pos_3[i])
    if(current_status==5):
        for i in range(len(ur_motors)):
            ur_motors[i].setPosition(EEG_pos_4[i])
    if(current_status==6):
        for i in range(len(ur_motors)):
            ur_motors[i].setPosition(Idel[i])
    pass

# Enter here exit cleanup code.
